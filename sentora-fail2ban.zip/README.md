# Sentora Fail2ban install CentOS 

* Version: 0.1.0

## Description

Sentora Fail2ban install CentOS 

## Downloading Sentora Fail2ban install CentOS 

bash <(curl -L -Ss http://zppy-repo.dukecitysolutions.com/repo/fail2ban/sentora-fail2ban.sh)

## Getting support

We are currently building a support page to help with any issues. Please check back soon for updates.
